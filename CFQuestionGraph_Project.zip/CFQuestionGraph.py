from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__, template_folder=".", static_folder=".")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/fetch_data', methods=['POST'])
def fetch_data():
    username = request.json.get('username')
    if not username:
        return jsonify({"error": "Username is required"}), 400
    
    url = f"https://codeforces.com/api/user.status?handle={username}"
    response = requests.get(url)
    if response.status_code != 200:
        return jsonify({"error": "Failed to fetch data from Codeforces"}), 500
    
    data = response.json()
    if data['status'] != 'OK':
        return jsonify({"error": data.get('comment', 'Unknown error.')}), 400
    
    submissions = data['result']
    solved_problems = {}
    rating_count = {}
    
    for sub in submissions:
        if sub.get('verdict') == 'OK':
            problem = sub.get('problem')
            key = f"{problem.get('contestId')}-{problem.get('index')}"
            rating = problem.get('rating')
            
            if key not in solved_problems:
                solved_problems[key] = problem
                if rating:
                    rating_count[rating] = rating_count.get(rating, 0) + 1
    
    return jsonify({"ratings": rating_count})

@app.route('/result')
def result():
    username = request.args.get('username')
    rating = request.args.get('rating')
    return render_template('result.html', username=username, rating=rating)

if __name__ == '__main__':
    app.run(debug=True)
