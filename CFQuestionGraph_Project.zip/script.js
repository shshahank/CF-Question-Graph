document.getElementById('fetchForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    fetch('/fetch_data', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({username})
    })
    .then(response => response.json())
    .then(data => {
        console.log('API Response:', data);
        if (data.error) {
            alert(data.error);
            return;
        }
        
        const ratings = Object.keys(data.ratings).map(Number).sort((a, b) => a - b);
        const counts = ratings.map(rating => data.ratings[rating] || 0);

        const ctx = document.getElementById('ratingChart').getContext('2d');
        if (window.ratingChart) window.ratingChart.destroy();

        window.ratingChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ratings,
                datasets: [{ label: 'Problems Solved', data: counts }]
            }
        });
    });
});